﻿#include <windows.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include <iostream>
#include <assert.h>
#include <atlimage.h>

constexpr int WINSIZE_X = 450;
constexpr int WINSIZE_Y = 450;

// 전역 변수:
HINSTANCE g_hInst;                                // 현재 인스턴스입니다.

LPCTSTR lpszClass = L"Window Class Name";
LPCTSTR lpszWindowName = L"Client";

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // 전역 문자열을 초기화합니다.
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    MSG msg;

    // 기본 메시지 루프입니다:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
    }

    return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style =
        CS_HREDRAW 	    // 클라이언트의 너비를 변경하면, 전체 윈도우를 다시 그리게 한다.
        | CS_VREDRAW	// 클라이언트의 높이를 변경하면, 전체 윈도우를 다시 그리게 한다.
    //	| CS_DBLCLKS	// 해당 윈도우에서 더블클릭을 사용해야 한다면 추가해야 한다.
        ;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;

    wcex.hIcon          = LoadIcon(hInstance, IDI_APPLICATION);
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = lpszClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, IDI_APPLICATION);

    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   g_hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

   DWORD dwStyle =
       WS_OVERLAPPED 	    // 디폴트 윈도우. 타이틀 바와 크기 조절이 안되는 경계선을 가진다. 아무런 스타일도 주지 않으면 이 스타일이 적용된다.
       | WS_CAPTION 		// 타이틀 바를 가진 윈도우를 만들며 WS_BORDER 스타일을 포함한다.
       | WS_SYSMENU		    // 시스템 메뉴를 가진 윈도우를 만든다.
       | WS_MINIMIZEBOX	    // 최소화 버튼을 만든다.
       | WS_BORDER			// 단선으로 된 경계선을 만들며 크기 조정은 할 수 없다.
       ;					// 추가로 필요한 윈도우 스타일은 http://www.soen.kr/lecture/win32api/reference/Function/CreateWindow.htm 참고.

   HWND hWnd = CreateWindowW(
       lpszClass,
       lpszWindowName,
       dwStyle,
       0, 
       0, 
       WINSIZE_X,
       WINSIZE_Y,
       nullptr, 
       nullptr, 
       hInstance, 
       nullptr
   );

   if (!hWnd) return FALSE;

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static int width = 0;
    static int height = 0;
    static RECT table[8][8];
    switch (message)
    {
    case WM_CREATE: break;
    case WM_KEYDOWN: {
        switch (wParam) {
        case VK_LEFT:
            width -= 50;
            if (width < 0)
                width = 0;
            break;
        case VK_RIGHT:
            width += 50;
            if (width > 350)
                width = 350;
            break;
        case VK_DOWN:
            height += 50;
            if (height > 350)
                height = 350;
            break;
        case VK_UP:
            height -= 50;
            if (height < 0)
                height = 0;
            break;
        }
        InvalidateRect(hWnd, NULL, TRUE);
        break;
    }
    case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            HBRUSH hBrush, oldBrush;

            for (int i = 0; i < 8; ++i) {
                for (int j = 0; j < 8; ++j) {
                    table[i][j].left = 0 + i * 50;
                    table[i][j].right = 50 + i * 50;
                    table[i][j].top = 0 + j * 50;
                    table[i][j].bottom = 50 + j * 50;
                    if (i % 2 == 1 && j % 2 == 0) {
                        hBrush = CreateSolidBrush(RGB(0, 0, 0));
                        oldBrush = (HBRUSH)SelectObject(hdc, hBrush);
                        Rectangle(hdc, table[i][j].left, table[i][j].top, table[i][j].right, table[i][j].bottom);
                        SelectObject(hdc, oldBrush);
                        DeleteObject(hBrush);
                    } else if (i%2 == 0 && j %2 == 1){
                        hBrush = CreateSolidBrush(RGB(0, 0, 0));
                        oldBrush = (HBRUSH)SelectObject(hdc, hBrush);
                        Rectangle(hdc, table[i][j].left, table[i][j].top, table[i][j].right, table[i][j].bottom);
                        SelectObject(hdc, oldBrush);
                        DeleteObject(hBrush);
                    } else {
                        Rectangle(hdc, table[i][j].left, table[i][j].top, table[i][j].right, table[i][j].bottom);
                    }
                }
            }
            hBrush = CreateSolidBrush(RGB(255, 0, 0));
            oldBrush = (HBRUSH)SelectObject(hdc, hBrush);

            Ellipse(hdc, width, height, width + 50, height + 50);
            SelectObject(hdc, oldBrush);
            DeleteObject(hBrush);
            // TODO: 여기에 hdc를 사용하는 그리기 코드를 추가합니다...
            EndPaint(hWnd, &ps);
            break;
        }
    case WM_DESTROY: {
        PostQuitMessage(0);
        break;
    }
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// 정보 대화 상자의 메시지 처리기입니다.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
