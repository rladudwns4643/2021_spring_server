#include <iostream>
#include <WS2tcpip.h>
using namespace std;
#pragma comment(lib, "WS2_32.lib")
constexpr int BUF_SIZE = 1024;
constexpr int PORT = 3500;

void err_display(const char* msg, int err_no) {
	WCHAR* m_msg;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, err_no,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&m_msg, 0, NULL);
	cout << msg;
	wcout << L"  ����: " << m_msg << endl;
	while (true);
	LocalFree(m_msg);
}

#pragma pack(1)
struct Player {
	int x;
	int y;
	int input;
};
#pragma pack()

Player p;

int main() {
	wcout.imbue(std::locale("korean"));
	WSADATA wsa;
	WSAStartup(MAKEWORD(2, 0), &wsa);
	SOCKET s = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, 0);
	SOCKADDR_IN s_a;
	ZeroMemory(&s_a, sizeof(s_a));
	
	s_a.sin_family = AF_INET;
	s_a.sin_port = htons(PORT);
	s_a.sin_addr.S_un.S_addr = INADDR_ANY;

	::bind(s, (sockaddr*)&s_a, sizeof(s_a));
	listen(s, SOMAXCONN);

	while (true) {
		SOCKADDR_IN c_a;
		int addrSize = sizeof(c_a);
		ZeroMemory(&c_a, sizeof(SOCKADDR_IN));
		SOCKET c = WSAAccept(s, (sockaddr*)&c_a, &addrSize, NULL, NULL);
		if (SOCKET_ERROR == c) { err_display("WSAAccprt", WSAGetLastError()); };

		cout << "NEW Client\n";

		while (true) {
			recv(c, (char*)&p, sizeof(Player), 0);
			if (p.input == 1) {
				p.x -= 50;
				if (p.x < 0) p.x = 0;
			}
			if (p.input == 2) {
				p.x += 50;
				if (p.x > 400) p.x = 400;
			}
			if (p.input == 3) {
				p.y += 50;
				if (p.y > 400) p.y = 400;
			}
			if (p.input == 4) {
				p.y -= 50;
				if (p.y < 0) p.y = 0;
			}
			send(c, (char*)&p, sizeof(Player), 0);
		}
		cout << "Client connect close\n";
	}
	closesocket(s);
	WSACleanup();
}